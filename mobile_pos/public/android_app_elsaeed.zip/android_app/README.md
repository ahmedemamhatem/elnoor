# Mobile POS Android App

Android WebView application for running Mobile POS on Sunyard POS terminals with integrated printer and scanner support.

## Features

- **WebView-based**: Loads the Frappe Mini POS web page
- **Native Printing**: Direct thermal receipt printing via Sunyard SDK
- **Barcode Scanner**: Hardware barcode scanner integration
- **Beeper & LED**: Audio and visual feedback
- **Auto-start**: Option to start app on device boot
- **Offline Support**: Service worker caching for offline use

## Requirements

- Android 7.0+ (API 24+)
- Sunyard POS Terminal with SDK service installed
- Network access to Frappe server

## Project Structure

```
android_app/
├── app/
│   ├── src/main/
│   │   ├── java/com/mobilepos/app/
│   │   │   ├── MainActivity.java          # Main WebView activity
│   │   │   ├── bridge/
│   │   │   │   └── SunyardBridge.java     # JavaScript interface
│   │   │   ├── service/
│   │   │   │   └── DeviceServiceManager.java  # SDK service manager
│   │   │   └── receiver/
│   │   │       └── BootReceiver.java      # Auto-start on boot
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/strings.xml
│   │   │   └── xml/network_security_config.xml
│   │   └── AndroidManifest.xml
│   ├── libs/
│   │   └── sunyardapi_v1.6.19_202509021514.jar
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Configuration

### 1. Server URL

Edit `MainActivity.java` and change the POS_URL constant:

```java
private static final String POS_URL = "http://your-server.com/app/mini-pos";
```

### 2. Network Security

For HTTPS servers, update `res/xml/network_security_config.xml`:

```xml
<domain-config cleartextTrafficPermitted="false">
    <domain includeSubdomains="true">your-server.com</domain>
</domain-config>
```

## Building the APK

### Prerequisites

1. Install Android Studio or Android SDK Command Line Tools
2. Set ANDROID_HOME environment variable
3. Install Java JDK 8 or higher

### Build Steps

#### Option 1: Using Android Studio

1. Open the `android_app` folder in Android Studio
2. Wait for Gradle sync to complete
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK will be in `app/build/outputs/apk/`

#### Option 2: Command Line

```bash
# Navigate to project directory
cd android_app

# Build debug APK
./gradlew assembleDebug

# Build release APK (requires signing config)
./gradlew assembleRelease

# APK location
ls -la app/build/outputs/apk/debug/
```

### Signing for Release

1. Generate a keystore:
```bash
keytool -genkey -v -keystore mobilepos-release.keystore -alias mobilepos -keyalg RSA -keysize 2048 -validity 10000
```

2. Add to `app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            storeFile file("mobilepos-release.keystore")
            storePassword "your-store-password"
            keyAlias "mobilepos"
            keyPassword "your-key-password"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

## Installation

### Via ADB

```bash
adb install -r MobilePOS_v1.0.0_*.apk
```

### Via File Manager

1. Copy APK to device storage
2. Open file manager on device
3. Navigate to APK and tap to install
4. Enable "Install from unknown sources" if prompted

## JavaScript Bridge API

The app exposes an `Android` object to JavaScript with these methods:

### Availability Checks

```javascript
// Check if running in Android POS app
Android.isAvailable()          // Returns: boolean

// Check specific hardware
Android.isPrinterAvailable()   // Returns: boolean
Android.isScannerAvailable()   // Returns: boolean

// Get SDK version
Android.getSDKVersion()        // Returns: string
```

### Printing

```javascript
// Print POS receipt (JSON data)
Android.printReceipt(jsonString)

// Print plain text
Android.printText(text, align, fontSize)
// align: 0=LEFT, 1=CENTER, 2=RIGHT
// fontSize: 0=NORMAL, 1=LARGE, 2=SMALL

// Print QR code
Android.printQRCode(data, size)

// Print barcode
Android.printBarcode(data, width, height)

// Print image (Base64)
Android.printImage(base64Data)

// Feed paper
Android.feedPaper(lines)
```

### Scanning

```javascript
// Start barcode scan
Android.startScan()

// Stop scanning
Android.stopScan()
```

### Other Hardware

```javascript
// Beep sound
Android.beep(durationMs)

// LED control (0=GREEN, 1=RED, 2=YELLOW, 3=BLUE)
Android.setLed(color, on)
```

### Callbacks (set on window object)

```javascript
// Print callbacks
window.onPrintSuccess = function(message) { }
window.onPrintError = function(error) { }

// Scan callbacks
window.onScanSuccess = function(barcode) { }
window.onScanError = function(error) { }
window.onScanCancel = function() { }
window.onScanTimeout = function() { }
```

## Receipt Data Format

```javascript
{
    "invoice_name": "INV-00001",
    "customer_name": "Customer Name",
    "items": [
        {
            "item_code": "ITEM001",
            "item_name": "Item Name",
            "qty": 2,
            "rate": 10.00
        }
    ],
    "total": 20.00,
    "discount": 0,
    "grand_total": 20.00,
    "paid_amount": 20.00,
    "payment_mode": "Cash",
    "custom_hash": "",
    "is_return": false,
    "customer_balance": 0,
    "company_name": "Company Name",
    "date": "2024-01-01",
    "time": "12:00:00"
}
```

## Troubleshooting

### Printer not working

1. Check if Sunyard SDK service is installed on device
2. Verify SDK service is running: Settings > Apps > Sunyard SDK
3. Check logcat for errors: `adb logcat -s SunyardBridge`

### WebView not loading

1. Check network connectivity
2. Verify server URL is correct
3. Check network_security_config.xml for HTTP/HTTPS settings
4. Look for SSL certificate errors in logcat

### Scanner not responding

1. Ensure scanner hardware is available on device
2. Check scanner permissions in app settings
3. Try restarting the SDK service

## Version History

- **1.0.0** - Initial release
  - WebView with Mini POS
  - Sunyard SDK integration
  - Native receipt printing
  - Barcode scanner support
  - Boot auto-start

## License

Proprietary - For internal use only.
