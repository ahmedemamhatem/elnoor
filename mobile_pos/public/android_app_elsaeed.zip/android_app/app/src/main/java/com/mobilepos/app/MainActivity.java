package com.mobilepos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.mobilepos.app.bridge.SunyardBridge;
import com.mobilepos.app.service.DeviceServiceManager;

public class MainActivity extends Activity {
    private static final String TAG = "MobilePOS";

    // Configuration - Production server URL (main website)
    private static final String POS_URL = "https://elsaeed-eg.com";

    private WebView webView;
    private ProgressBar progressBar;
    private SunyardBridge sunyardBridge;
    private DeviceServiceManager deviceServiceManager;

    // File upload handling
    private ValueCallback<Uri[]> fileUploadCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Keep screen on for POS usage
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Initialize views
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        // Initialize Sunyard SDK service
        initDeviceService();

        // Setup WebView
        setupWebView();

        // Load POS URL
        loadPosUrl();
    }

    private void initDeviceService() {
        deviceServiceManager = DeviceServiceManager.getInstance();
        deviceServiceManager.init(this);
        deviceServiceManager.connect(new DeviceServiceManager.OnServiceConnectedListener() {
            @Override
            public void onServiceConnected() {
                Log.d(TAG, "Sunyard SDK Service Connected");
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "POS Hardware Ready", Toast.LENGTH_SHORT).show();
                });
                // Initialize bridge after service is connected
                sunyardBridge = new SunyardBridge(MainActivity.this, webView, deviceServiceManager);
                runOnUiThread(() -> {
                    webView.addJavascriptInterface(sunyardBridge, "Android");
                });
            }

            @Override
            public void onServiceDisconnected() {
                Log.e(TAG, "Sunyard SDK Service Disconnected");
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "POS Hardware Disconnected", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();

        // Enable JavaScript
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        // Enable DOM storage
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Enable cache
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAppCacheEnabled(true);

        // Enable zoom controls
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);

        // Enable viewport
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        // Enable mixed content (http in https)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // Enable file access
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // User agent - identify as Mobile POS App
        String userAgent = settings.getUserAgentString();
        settings.setUserAgentString(userAgent + " MobilePOS-Android/1.0 SunyardPOS");

        // Enable cookies
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        // Add JavaScript interface for Android bridge (basic, will be replaced after service connects)
        sunyardBridge = new SunyardBridge(this, webView, null);
        webView.addJavascriptInterface(sunyardBridge, "Android");

        // WebView client for page loading
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);

                // Inject helper JS after page load
                injectHelperScript();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Log.e(TAG, "WebView error: " + error.getDescription());
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                // Allow navigation within elsaeed-eg.com domain
                if (url.contains("elsaeed-eg.com")) {
                    return false; // Let WebView handle it
                }

                // Handle external links - open in browser
                if (!url.contains("localhost") && !url.contains("127.0.0.1") && !url.contains("192.168.")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        // Chrome client for advanced features
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "JS Console: " + consoleMessage.message() + " -- Line " + consoleMessage.lineNumber());
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(request.getResources());
                }
            }

            // Handle file uploads
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                fileUploadCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Select File"), FILE_CHOOSER_REQUEST_CODE);
                return true;
            }
        });
    }

    private void loadPosUrl() {
        // Check for custom URL in intent
        String url = getIntent().getStringExtra("pos_url");
        if (url == null || url.isEmpty()) {
            url = POS_URL;
        }
        webView.loadUrl(url);
    }

    private void injectHelperScript() {
        String script =
            "(function() {" +
            "  if (window.AndroidBridgeReady) return;" +
            "  window.AndroidBridgeReady = true;" +
            "  console.log('Android Bridge Ready');" +
            "  " +
            "  // Dispatch event to notify JS that Android bridge is available" +
            "  window.dispatchEvent(new CustomEvent('androidBridgeReady'));" +
            "  " +
            "  // Helper function to check if running in Android app" +
            "  window.isAndroidPOSApp = function() {" +
            "    return typeof Android !== 'undefined' && Android.isAvailable && Android.isAvailable();" +
            "  };" +
            "})();";

        webView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (fileUploadCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
                fileUploadCallback.onReceiveValue(results);
                fileUploadCallback = null;
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Handle back button
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }

        // Handle scanner hardware button (if applicable)
        if (keyCode == KeyEvent.KEYCODE_F1 || keyCode == KeyEvent.KEYCODE_BUTTON_1) {
            if (sunyardBridge != null) {
                sunyardBridge.startScan();
            }
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Disconnect SDK service
        if (deviceServiceManager != null) {
            deviceServiceManager.disconnect();
        }

        // Cleanup WebView
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
    }

    // Public method to show toast from bridge
    public void showToast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    // Public method to reload WebView
    public void reloadWebView() {
        runOnUiThread(() -> webView.reload());
    }
}
