package com.mobilepos.app.bridge;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.mobilepos.app.MainActivity;
import com.mobilepos.app.service.DeviceServiceManager;
import com.sunyard.api.beep.IBeeper;
import com.sunyard.api.led.ILed;
import com.sunyard.api.led.LedConstant;
import com.sunyard.api.printer.IPrinter;
import com.sunyard.api.printer.OnPrintListener;
import com.sunyard.api.printer.PrintConstant;
import com.sunyard.api.printer.PrinterChip;
import com.sunyard.api.scanner.IScanner;
import com.sunyard.api.scanner.OnScanListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/**
 * JavaScript Interface Bridge for Sunyard POS SDK
 * Exposes native hardware functionality to the WebView JavaScript
 */
public class SunyardBridge {
    private static final String TAG = "SunyardBridge";

    private final MainActivity activity;
    private final WebView webView;
    private DeviceServiceManager deviceServiceManager;
    private Handler mainHandler;

    // Scan callback state
    private boolean isScanningActive = false;

    public SunyardBridge(MainActivity activity, WebView webView, DeviceServiceManager deviceServiceManager) {
        this.activity = activity;
        this.webView = webView;
        this.deviceServiceManager = deviceServiceManager;
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void setDeviceServiceManager(DeviceServiceManager manager) {
        this.deviceServiceManager = manager;
    }

    // ==================== Availability Check ====================

    @JavascriptInterface
    public boolean isAvailable() {
        return deviceServiceManager != null && deviceServiceManager.isConnected();
    }

    @JavascriptInterface
    public boolean isPrinterAvailable() {
        return isAvailable() && deviceServiceManager.getPrinter() != null;
    }

    @JavascriptInterface
    public boolean isScannerAvailable() {
        return isAvailable() && deviceServiceManager.getScanner() != null;
    }

    @JavascriptInterface
    public String getSDKVersion() {
        if (deviceServiceManager != null) {
            return deviceServiceManager.getSDKVersion();
        }
        return "Not connected";
    }

    // ==================== Printer Functions ====================

    /**
     * Print a POS receipt
     * @param jsonData JSON string containing receipt data:
     * {
     *   "invoice_name": "INV-001",
     *   "customer_name": "Customer",
     *   "items": [{"item_name": "Item 1", "qty": 2, "rate": 10.00}],
     *   "total": 20.00,
     *   "discount": 0,
     *   "grand_total": 20.00,
     *   "paid_amount": 20.00,
     *   "payment_mode": "Cash",
     *   "is_return": false,
     *   "customer_balance": 0,
     *   "custom_hash": "",
     *   "company_name": "Company",
     *   "date": "2024-01-01",
     *   "time": "12:00:00"
     * }
     */
    @JavascriptInterface
    public void printReceipt(String jsonData) {
        Log.d(TAG, "printReceipt called with: " + jsonData);

        if (!isPrinterAvailable()) {
            callJSCallback("onPrintError", "Printer not available");
            return;
        }

        try {
            JSONObject data = new JSONObject(jsonData);
            printPOSReceipt(data);
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing receipt data", e);
            callJSCallback("onPrintError", "Invalid receipt data: " + e.getMessage());
        }
    }

    private void printPOSReceipt(JSONObject data) {
        try {
            IPrinter printer = deviceServiceManager.getPrinter();
            if (printer == null) {
                callJSCallback("onPrintError", "Printer not available");
                return;
            }

            // Set print density/gray level
            printer.setGray(8);

            String invoiceName = data.optString("invoice_name", "");
            String customerName = data.optString("customer_name", "");
            String companyName = data.optString("company_name", "Mobile POS");
            String dateStr = data.optString("date", "");
            String timeStr = data.optString("time", "");
            String customHash = data.optString("custom_hash", "");
            String paymentMode = data.optString("payment_mode", "");
            double total = data.optDouble("total", 0);
            double discount = data.optDouble("discount", 0);
            double grandTotal = data.optDouble("grand_total", 0);
            double paidAmount = data.optDouble("paid_amount", 0);
            double customerBalance = data.optDouble("customer_balance", 0);
            boolean isReturn = data.optBoolean("is_return", false);
            JSONArray items = data.optJSONArray("items");

            Bundle centerBundle = new Bundle();
            centerBundle.putInt("align", PrintConstant.Align.CENTER);
            centerBundle.putInt("font", PrintConstant.FontSize.NORMAL);

            Bundle leftBundle = new Bundle();
            leftBundle.putInt("align", PrintConstant.Align.LEFT);
            leftBundle.putInt("font", PrintConstant.FontSize.NORMAL);

            Bundle rightBundle = new Bundle();
            rightBundle.putInt("align", PrintConstant.Align.RIGHT);
            rightBundle.putInt("font", PrintConstant.FontSize.NORMAL);

            Bundle largeCenterBundle = new Bundle();
            largeCenterBundle.putInt("align", PrintConstant.Align.CENTER);
            largeCenterBundle.putInt("font", PrintConstant.FontSize.LARGE);

            // ===== Header =====
            printer.addText(largeCenterBundle, companyName);
            printer.addText(centerBundle, isReturn ? "فاتورة مرتجع" : "فاتورة بيع");
            printer.addText(centerBundle, "================================");

            // ===== Invoice Info =====
            printer.addText(leftBundle, "رقم الفاتورة: " + invoiceName);
            printer.addText(leftBundle, "العميل: " + customerName);
            printer.addText(leftBundle, "التاريخ: " + dateStr);
            printer.addText(leftBundle, "الوقت: " + timeStr);
            if (!customHash.isEmpty()) {
                printer.addText(leftBundle, "رقم القيد: " + customHash);
            }
            printer.addText(centerBundle, "--------------------------------");

            // ===== Items Header =====
            ArrayList<PrinterChip> headerChips = new ArrayList<>();
            PrinterChip itemHeader = new PrinterChip("الصنف", 0.4f, 0);
            itemHeader.setFontSize(0);
            headerChips.add(itemHeader);
            PrinterChip qtyHeader = new PrinterChip("الكمية", 0.2f, 1);
            qtyHeader.setFontSize(0);
            headerChips.add(qtyHeader);
            PrinterChip rateHeader = new PrinterChip("السعر", 0.2f, 1);
            rateHeader.setFontSize(0);
            headerChips.add(rateHeader);
            PrinterChip totalHeader = new PrinterChip("المجموع", 0.2f, 2);
            totalHeader.setFontSize(0);
            headerChips.add(totalHeader);
            printer.addTextChips(headerChips);

            printer.addText(centerBundle, "--------------------------------");

            // ===== Items =====
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.getJSONObject(i);
                    String itemName = item.optString("item_name", item.optString("item_code", ""));
                    double qty = item.optDouble("qty", 0);
                    double rate = item.optDouble("rate", 0);
                    double itemTotal = qty * rate;

                    ArrayList<PrinterChip> itemChips = new ArrayList<>();

                    PrinterChip nameChip = new PrinterChip(itemName, 0.4f, 0);
                    nameChip.setFontSize(0);
                    itemChips.add(nameChip);

                    PrinterChip qtyChip = new PrinterChip(formatNumber(qty), 0.2f, 1);
                    qtyChip.setFontSize(0);
                    itemChips.add(qtyChip);

                    PrinterChip rateChip = new PrinterChip(formatCurrency(rate), 0.2f, 1);
                    rateChip.setFontSize(0);
                    itemChips.add(rateChip);

                    PrinterChip totalChip = new PrinterChip(formatCurrency(itemTotal), 0.2f, 2);
                    totalChip.setFontSize(0);
                    itemChips.add(totalChip);

                    printer.addTextChips(itemChips);
                }
            }

            printer.addText(centerBundle, "================================");

            // ===== Totals =====
            printTwoColumnRow(printer, "المجموع:", formatCurrency(total));

            if (discount > 0) {
                printTwoColumnRow(printer, "الخصم:", "-" + formatCurrency(discount));
            }

            // Grand total with larger font
            Bundle grandTotalBundle = new Bundle();
            grandTotalBundle.putInt("align", PrintConstant.Align.LEFT);
            grandTotalBundle.putInt("font", PrintConstant.FontSize.LARGE);
            printer.addText(grandTotalBundle, "الإجمالي: " + formatCurrency(grandTotal));

            printer.addText(centerBundle, "--------------------------------");

            // ===== Payment Info =====
            if (paidAmount > 0) {
                String paidLabel = isReturn ? "المسترجع" : "المدفوع";
                printTwoColumnRow(printer, paidLabel + " (" + paymentMode + "):", formatCurrency(paidAmount));

                if (!isReturn) {
                    double remaining = grandTotal - paidAmount;
                    printTwoColumnRow(printer, "المتبقي:", formatCurrency(remaining));
                }
            }

            printer.addText(centerBundle, "================================");

            // ===== Customer Balance =====
            String balanceLabel = customerBalance > 0 ? "مدين" : "دائن";
            printer.addText(leftBundle, "رصيد العميل: " + formatCurrency(Math.abs(customerBalance)) + " " + balanceLabel);

            printer.addText(centerBundle, "--------------------------------");

            // ===== Footer =====
            printer.addText(centerBundle, "شكراً لتعاملكم معنا");
            printer.addText(centerBundle, "Thank you!");

            // Feed paper
            printer.feedLine(4);

            // Start printing
            printer.startPrint(new OnPrintListener.Stub() {
                @Override
                public void onFinish() throws RemoteException {
                    Log.d(TAG, "Print finished successfully");
                    callJSCallback("onPrintSuccess", "Receipt printed successfully");
                    beepSuccess();
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    String errorMsg = getPrintErrorMessage(errorCode);
                    Log.e(TAG, "Print error: " + errorMsg);
                    callJSCallback("onPrintError", errorMsg);
                    beepError();
                }
            });

        } catch (RemoteException e) {
            Log.e(TAG, "RemoteException during printing", e);
            callJSCallback("onPrintError", "Print error: " + e.getMessage());
        } catch (JSONException e) {
            Log.e(TAG, "JSONException during printing", e);
            callJSCallback("onPrintError", "Data error: " + e.getMessage());
        }
    }

    private void printTwoColumnRow(IPrinter printer, String left, String right) throws RemoteException {
        ArrayList<PrinterChip> chips = new ArrayList<>();
        PrinterChip leftChip = new PrinterChip(left, 0.5f, 0);
        leftChip.setFontSize(0);
        chips.add(leftChip);
        PrinterChip rightChip = new PrinterChip(right, 0.5f, 2);
        rightChip.setFontSize(0);
        chips.add(rightChip);
        printer.addTextChips(chips);
    }

    /**
     * Print plain text
     */
    @JavascriptInterface
    public void printText(String text, int align, int fontSize) {
        if (!isPrinterAvailable()) {
            callJSCallback("onPrintError", "Printer not available");
            return;
        }

        try {
            IPrinter printer = deviceServiceManager.getPrinter();
            Bundle bundle = new Bundle();
            bundle.putInt("align", align); // 0=LEFT, 1=CENTER, 2=RIGHT
            bundle.putInt("font", fontSize); // 0=NORMAL, 1=LARGE, 2=SMALL
            printer.addText(bundle, text);
            printer.feedLine(2);
            printer.startPrint(new OnPrintListener.Stub() {
                @Override
                public void onFinish() throws RemoteException {
                    callJSCallback("onPrintSuccess", "Text printed");
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    callJSCallback("onPrintError", getPrintErrorMessage(errorCode));
                }
            });
        } catch (RemoteException e) {
            callJSCallback("onPrintError", e.getMessage());
        }
    }

    /**
     * Print QR code
     */
    @JavascriptInterface
    public void printQRCode(String data, int size) {
        if (!isPrinterAvailable()) {
            callJSCallback("onPrintError", "Printer not available");
            return;
        }

        try {
            IPrinter printer = deviceServiceManager.getPrinter();
            Bundle bundle = new Bundle();
            bundle.putInt("align", PrintConstant.Align.CENTER);
            bundle.putInt("expectedHeight", size > 0 ? size : 200);
            printer.addQrCode(bundle, data);
            printer.feedLine(2);
            printer.startPrint(new OnPrintListener.Stub() {
                @Override
                public void onFinish() throws RemoteException {
                    callJSCallback("onPrintSuccess", "QR Code printed");
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    callJSCallback("onPrintError", getPrintErrorMessage(errorCode));
                }
            });
        } catch (RemoteException e) {
            callJSCallback("onPrintError", e.getMessage());
        }
    }

    /**
     * Print barcode
     */
    @JavascriptInterface
    public void printBarcode(String data, int width, int height) {
        if (!isPrinterAvailable()) {
            callJSCallback("onPrintError", "Printer not available");
            return;
        }

        try {
            IPrinter printer = deviceServiceManager.getPrinter();
            Bundle bundle = new Bundle();
            bundle.putInt("align", PrintConstant.Align.CENTER);
            bundle.putInt("width", width > 0 ? width : 400);
            bundle.putInt("height", height > 0 ? height : 100);
            printer.addBarCode(bundle, data);
            printer.feedLine(2);
            printer.startPrint(new OnPrintListener.Stub() {
                @Override
                public void onFinish() throws RemoteException {
                    callJSCallback("onPrintSuccess", "Barcode printed");
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    callJSCallback("onPrintError", getPrintErrorMessage(errorCode));
                }
            });
        } catch (RemoteException e) {
            callJSCallback("onPrintError", e.getMessage());
        }
    }

    /**
     * Print image from Base64
     */
    @JavascriptInterface
    public void printImage(String base64Data) {
        if (!isPrinterAvailable()) {
            callJSCallback("onPrintError", "Printer not available");
            return;
        }

        try {
            byte[] imageBytes = Base64.decode(base64Data, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);

            if (bitmap == null) {
                callJSCallback("onPrintError", "Invalid image data");
                return;
            }

            IPrinter printer = deviceServiceManager.getPrinter();
            Bundle bundle = new Bundle();
            bundle.putInt("offset", 0);
            printer.addImage(bundle, bitmapToByteArray(bitmap));
            printer.feedLine(2);
            printer.startPrint(new OnPrintListener.Stub() {
                @Override
                public void onFinish() throws RemoteException {
                    callJSCallback("onPrintSuccess", "Image printed");
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    callJSCallback("onPrintError", getPrintErrorMessage(errorCode));
                }
            });
        } catch (Exception e) {
            callJSCallback("onPrintError", e.getMessage());
        }
    }

    /**
     * Feed paper lines
     */
    @JavascriptInterface
    public void feedPaper(int lines) {
        if (!isPrinterAvailable()) return;

        try {
            IPrinter printer = deviceServiceManager.getPrinter();
            printer.feedLine(lines);
            printer.startPrint(null);
        } catch (RemoteException e) {
            Log.e(TAG, "Feed paper error", e);
        }
    }

    // ==================== Scanner Functions ====================

    /**
     * Start barcode scanning
     */
    @JavascriptInterface
    public void startScan() {
        if (!isScannerAvailable()) {
            callJSCallback("onScanError", "Scanner not available");
            return;
        }

        if (isScanningActive) {
            Log.d(TAG, "Scan already active");
            return;
        }

        try {
            IScanner scanner = deviceServiceManager.getScanner();
            isScanningActive = true;

            scanner.startScan(30000, new OnScanListener.Stub() {
                @Override
                public void onSuccess(String barcode) throws RemoteException {
                    Log.d(TAG, "Scan success: " + barcode);
                    isScanningActive = false;
                    callJSCallback("onScanSuccess", barcode);
                    beepSuccess();
                }

                @Override
                public void onError(int errorCode) throws RemoteException {
                    Log.e(TAG, "Scan error: " + errorCode);
                    isScanningActive = false;
                    callJSCallback("onScanError", "Scan error code: " + errorCode);
                }

                @Override
                public void onCancel() throws RemoteException {
                    Log.d(TAG, "Scan cancelled");
                    isScanningActive = false;
                    callJSCallback("onScanCancel", "Scan cancelled");
                }

                @Override
                public void onTimeout() throws RemoteException {
                    Log.d(TAG, "Scan timeout");
                    isScanningActive = false;
                    callJSCallback("onScanTimeout", "Scan timeout");
                }
            });
        } catch (RemoteException e) {
            isScanningActive = false;
            callJSCallback("onScanError", e.getMessage());
        }
    }

    /**
     * Stop barcode scanning
     */
    @JavascriptInterface
    public void stopScan() {
        if (!isScannerAvailable()) return;

        try {
            IScanner scanner = deviceServiceManager.getScanner();
            scanner.stopScan();
            isScanningActive = false;
        } catch (RemoteException e) {
            Log.e(TAG, "Stop scan error", e);
        }
    }

    // ==================== Beeper Functions ====================

    /**
     * Play beep sound
     */
    @JavascriptInterface
    public void beep(int duration) {
        if (!isAvailable()) return;

        try {
            IBeeper beeper = deviceServiceManager.getBeeper();
            if (beeper != null) {
                beeper.beep(duration > 0 ? duration : 100);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "Beep error", e);
        }
    }

    private void beepSuccess() {
        beep(100);
    }

    private void beepError() {
        try {
            IBeeper beeper = deviceServiceManager.getBeeper();
            if (beeper != null) {
                beeper.beep(200);
                Thread.sleep(100);
                beeper.beep(200);
            }
        } catch (Exception e) {
            Log.e(TAG, "Beep error", e);
        }
    }

    // ==================== LED Functions ====================

    /**
     * Control LED
     * @param color 0=GREEN, 1=RED, 2=YELLOW, 3=BLUE
     * @param on true to turn on, false to turn off
     */
    @JavascriptInterface
    public void setLed(int color, boolean on) {
        if (!isAvailable()) return;

        try {
            ILed led = deviceServiceManager.getLed();
            if (led != null) {
                int ledColor;
                switch (color) {
                    case 0: ledColor = LedConstant.Light.GREEN; break;
                    case 1: ledColor = LedConstant.Light.RED; break;
                    case 2: ledColor = LedConstant.Light.YELLOW; break;
                    case 3: ledColor = LedConstant.Light.BLUE; break;
                    default: ledColor = LedConstant.Light.GREEN;
                }

                if (on) {
                    led.turnOn(ledColor);
                } else {
                    led.turnOff(ledColor);
                }
            }
        } catch (RemoteException e) {
            Log.e(TAG, "LED error", e);
        }
    }

    // ==================== Utility Functions ====================

    private String formatCurrency(double value) {
        return String.format("%.2f", value);
    }

    private String formatNumber(double value) {
        if (value == (int) value) {
            return String.valueOf((int) value);
        }
        return String.format("%.2f", value);
    }

    private byte[] bitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        return outputStream.toByteArray();
    }

    private String getPrintErrorMessage(int errorCode) {
        switch (errorCode) {
            case 1: return "Printer busy";
            case 2: return "Out of paper";
            case 3: return "Paper jam";
            case 4: return "Printer overheat";
            case 5: return "Printer voltage error";
            case 6: return "Print data error";
            default: return "Print error code: " + errorCode;
        }
    }

    /**
     * Call JavaScript callback function
     */
    private void callJSCallback(final String functionName, final String data) {
        mainHandler.post(() -> {
            String script = "if (typeof window." + functionName + " === 'function') { window." + functionName + "('" + escapeJS(data) + "'); }";
            webView.evaluateJavascript(script, null);
        });
    }

    private String escapeJS(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("'", "\\'")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r");
    }
}
