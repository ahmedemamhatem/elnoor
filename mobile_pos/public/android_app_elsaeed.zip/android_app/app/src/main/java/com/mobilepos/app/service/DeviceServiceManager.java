package com.mobilepos.app.service;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.sunyard.api.IDeviceService;
import com.sunyard.api.beep.IBeeper;
import com.sunyard.api.deviceinfo.IDeviceInfo;
import com.sunyard.api.led.ILed;
import com.sunyard.api.printer.IPrinter;
import com.sunyard.api.scanner.IScanner;
import com.sunyard.api.scanner.OnScanListener;

/**
 * Singleton manager for Sunyard POS device SDK service
 * Handles connection to the SDK service and provides access to hardware interfaces
 */
public class DeviceServiceManager {
    private static final String TAG = "DeviceServiceManager";

    // Sunyard SDK Service package and action
    private static final String SDK_SERVICE_PACKAGE = "com.sunyard.sdk";
    private static final String SDK_SERVICE_ACTION = "com.sunyard.sdk.DeviceService";

    private static DeviceServiceManager instance;
    private IDeviceService deviceService;
    private Context context;
    private ServiceConnection serviceConnection;
    private OnServiceConnectedListener serviceConnectedListener;
    private boolean isConnected = false;

    // Cached hardware interfaces
    private IPrinter printer;
    private IScanner scanner;
    private IBeeper beeper;
    private ILed led;
    private IDeviceInfo deviceInfo;

    public interface OnServiceConnectedListener {
        void onServiceConnected();
        void onServiceDisconnected();
    }

    private DeviceServiceManager() {
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Log.d(TAG, "Service connected: " + name);
                deviceService = IDeviceService.Stub.asInterface(service);
                isConnected = true;

                // Pre-cache hardware interfaces
                try {
                    printer = getPrinter();
                    scanner = getScanner();
                    beeper = getBeeper();
                    led = getLed();
                    deviceInfo = getDeviceInfo();
                } catch (Exception e) {
                    Log.e(TAG, "Error caching hardware interfaces", e);
                }

                if (serviceConnectedListener != null) {
                    serviceConnectedListener.onServiceConnected();
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.d(TAG, "Service disconnected: " + name);
                deviceService = null;
                isConnected = false;
                printer = null;
                scanner = null;
                beeper = null;
                led = null;
                deviceInfo = null;

                if (serviceConnectedListener != null) {
                    serviceConnectedListener.onServiceDisconnected();
                }
            }
        };
    }

    public static synchronized DeviceServiceManager getInstance() {
        if (instance == null) {
            instance = new DeviceServiceManager();
        }
        return instance;
    }

    public void init(Context ctx) {
        this.context = ctx.getApplicationContext();
    }

    public void connect(OnServiceConnectedListener listener) {
        this.serviceConnectedListener = listener;

        if (context == null) {
            Log.e(TAG, "Context not initialized. Call init() first.");
            return;
        }

        try {
            Intent serviceIntent = new Intent();
            serviceIntent.setAction(SDK_SERVICE_ACTION);
            serviceIntent.setPackage(SDK_SERVICE_PACKAGE);

            boolean bound = context.bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
            if (bound) {
                Log.d(TAG, "Binding to Sunyard SDK service...");
            } else {
                Log.e(TAG, "Failed to bind to Sunyard SDK service");

                // Try alternative binding method
                tryAlternativeBinding();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error connecting to service", e);
        }
    }

    private void tryAlternativeBinding() {
        try {
            // Alternative: Try explicit component name
            Intent serviceIntent = new Intent();
            serviceIntent.setComponent(new ComponentName(
                    "com.sunyard.sdk",
                    "com.sunyard.sdk.DeviceService"
            ));

            boolean bound = context.bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
            if (bound) {
                Log.d(TAG, "Alternative binding successful");
            } else {
                Log.e(TAG, "Alternative binding also failed - SDK service may not be installed");
            }
        } catch (Exception e) {
            Log.e(TAG, "Alternative binding error", e);
        }
    }

    public void disconnect() {
        if (context != null && serviceConnection != null) {
            try {
                context.unbindService(serviceConnection);
            } catch (Exception e) {
                Log.e(TAG, "Error disconnecting service", e);
            }
        }
        isConnected = false;
    }

    public boolean isConnected() {
        return isConnected && deviceService != null;
    }

    // ==================== Hardware Interface Getters ====================

    public IPrinter getPrinter() {
        if (printer != null) return printer;

        if (deviceService == null) {
            Log.e(TAG, "Device service not connected");
            return null;
        }

        try {
            IBinder binder = deviceService.getPrinter();
            if (binder != null) {
                printer = IPrinter.Stub.asInterface(binder);
            }
            return printer;
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting printer", e);
            return null;
        }
    }

    public IScanner getScanner() {
        if (scanner != null) return scanner;

        if (deviceService == null) {
            Log.e(TAG, "Device service not connected");
            return null;
        }

        try {
            IBinder binder = deviceService.getScanner(0);
            if (binder != null) {
                scanner = IScanner.Stub.asInterface(binder);
            }
            return scanner;
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting scanner", e);
            return null;
        }
    }

    public IBeeper getBeeper() {
        if (beeper != null) return beeper;

        if (deviceService == null) {
            Log.e(TAG, "Device service not connected");
            return null;
        }

        try {
            IBinder binder = deviceService.getBeeper();
            if (binder != null) {
                beeper = IBeeper.Stub.asInterface(binder);
            }
            return beeper;
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting beeper", e);
            return null;
        }
    }

    public ILed getLed() {
        if (led != null) return led;

        if (deviceService == null) {
            Log.e(TAG, "Device service not connected");
            return null;
        }

        try {
            IBinder binder = deviceService.getLed();
            if (binder != null) {
                led = ILed.Stub.asInterface(binder);
            }
            return led;
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting LED", e);
            return null;
        }
    }

    public IDeviceInfo getDeviceInfo() {
        if (deviceInfo != null) return deviceInfo;

        if (deviceService == null) {
            Log.e(TAG, "Device service not connected");
            return null;
        }

        try {
            IBinder binder = deviceService.getDeviceInfo();
            if (binder != null) {
                deviceInfo = IDeviceInfo.Stub.asInterface(binder);
            }
            return deviceInfo;
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting device info", e);
            return null;
        }
    }

    public String getSDKVersion() {
        if (deviceService == null) return "Not connected";

        try {
            return deviceService.getVersion();
        } catch (RemoteException e) {
            Log.e(TAG, "Error getting SDK version", e);
            return "Error";
        }
    }
}
